import React from "react";

export default function RadioOptionGrid({ options, selected, onSelect }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {options.map((option) => {
        const isSelected = selected === option;
        return (
          <button
            key={option}
            type="button"
            onClick={() => onSelect(option)}
            className={`flex items-center gap-3 p-4 rounded-xl border-2 text-left text-lg font-medium transition-colors min-h-[56px] ${
              isSelected
                ? "border-[#0D9488] bg-[#F0FDFA] text-[#0D6B61]"
                : "border-[#F3F4F6] text-[#374151] hover:border-[#CCFBF1]"
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                isSelected ? "border-[#0D9488]" : "border-[#D1D5DB]"
              }`}
            >
              {isSelected && <span className="w-2.5 h-2.5 rounded-full bg-[#0D9488]" />}
            </span>
            {option}
          </button>
        );
      })}
    </div>
  );
}