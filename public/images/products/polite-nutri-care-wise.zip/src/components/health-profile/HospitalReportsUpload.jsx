import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Label } from "@/components/ui/label";
import { FileText, X, UploadCloud, Loader2 } from "lucide-react";

export default function HospitalReportsUpload({ reports, onChange }) {
  const [uploading, setUploading] = useState(false);

  const handleFiles = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setUploading(true);
    const uploaded = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      uploaded.push({ name: file.name, url: file_url });
    }
    onChange([...(reports || []), ...uploaded]);
    setUploading(false);
    e.target.value = "";
  };

  const removeReport = (index) => {
    onChange(reports.filter((_, i) => i !== index));
  };

  return (
    <div>
      <Label className="text-lg font-semibold text-[#134E4A] mb-3 block">
        Hospital Reports (optional)
      </Label>

      <div className="space-y-2 mb-3">
        {(reports || []).map((r, i) => (
          <div key={i} className="flex items-center justify-between gap-3 bg-[#F0FDFA] rounded-xl px-4 py-3">
            <div className="flex items-center gap-2 min-w-0">
              <FileText className="w-5 h-5 text-[#0D9488] shrink-0" />
              <span className="text-base text-[#134E4A] truncate">{r.name}</span>
            </div>
            <button
              type="button"
              onClick={() => removeReport(i)}
              className="shrink-0 text-[#6B7280] hover:text-[#DC2626]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ))}
      </div>

      <label className="flex items-center justify-center gap-2 h-14 px-6 rounded-xl border-2 border-dashed border-[#0D9488] text-[#0D9488] font-semibold text-lg cursor-pointer hover:bg-[#F0FDFA] transition-colors">
        {uploading ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" /> Uploading...
          </>
        ) : (
          <>
            <UploadCloud className="w-5 h-5" /> Upload Reports
          </>
        )}
        <input
          type="file"
          multiple
          accept=".pdf,.jpg,.jpeg,.png"
          onChange={handleFiles}
          disabled={uploading}
          className="hidden"
        />
      </label>
    </div>
  );
}