import React from "react";
import { Check } from "lucide-react";

export default function StepProgress({ steps, currentStep }) {
  return (
    <div className="flex items-center justify-center gap-2 sm:gap-4 mb-10">
      {steps.map((label, idx) => {
        const stepNum = idx + 1;
        const isDone = stepNum < currentStep;
        const isActive = stepNum === currentStep;
        return (
          <React.Fragment key={label}>
            <div className="flex flex-col items-center gap-2">
              <div
                className={`w-11 h-11 rounded-full flex items-center justify-center text-lg font-bold border-2 ${
                  isDone
                    ? "bg-[#0D9488] border-[#0D9488] text-white"
                    : isActive
                    ? "bg-white border-[#0D9488] text-[#0D9488]"
                    : "bg-white border-[#F3F4F6] text-[#9CA3AF]"
                }`}
              >
                {isDone ? <Check className="w-5 h-5" /> : stepNum}
              </div>
              <span
                className={`text-sm font-semibold hidden sm:block ${
                  isActive || isDone ? "text-[#134E4A]" : "text-[#9CA3AF]"
                }`}
              >
                {label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <div className={`w-8 sm:w-16 h-1 rounded-full ${isDone ? "bg-[#0D9488]" : "bg-[#F3F4F6]"}`} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}