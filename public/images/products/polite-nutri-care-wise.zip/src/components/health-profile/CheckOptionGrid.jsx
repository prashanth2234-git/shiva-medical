import React from "react";
import { Check } from "lucide-react";

export default function CheckOptionGrid({ options, selected, onToggle }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {options.map((option) => {
        const isSelected = selected.includes(option);
        return (
          <button
            key={option}
            type="button"
            onClick={() => onToggle(option)}
            className={`flex items-center gap-3 p-4 rounded-xl border-2 text-left text-lg font-medium transition-colors min-h-[56px] ${
              isSelected
                ? "border-[#0D9488] bg-[#F0FDFA] text-[#0D6B61]"
                : "border-[#F3F4F6] text-[#374151] hover:border-[#CCFBF1]"
            }`}
          >
            <span
              className={`w-6 h-6 rounded-md border-2 flex items-center justify-center shrink-0 ${
                isSelected ? "bg-[#0D9488] border-[#0D9488]" : "border-[#D1D5DB]"
              }`}
            >
              {isSelected && <Check className="w-4 h-4 text-white" />}
            </span>
            {option}
          </button>
        );
      })}
    </div>
  );
}