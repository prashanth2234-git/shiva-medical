import React from "react";

export default function MealCard({ meal, onClick }) {
  if (!meal) {
    return (
      <div className="rounded-xl border-2 border-dashed border-[#E5E7EB] p-5 text-[#6B7280] text-lg font-medium">
        No meal planned
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full text-left rounded-xl border-2 border-[#0D9488] hover:bg-[#F0FDFA] hover:shadow-lg bg-white p-5 transition-all"
    >
      <div className="min-w-0 flex-1">
        <p className="text-xl font-bold text-[#134E4A] mb-1 break-words line-clamp-2">{meal.mealName}</p>
        <p className="text-lg text-[#374151] mb-2 break-words line-clamp-2">{meal.description}</p>
        <p className="text-base font-bold text-[#0D6B61] break-words">{meal.calories} cal · {meal.protein}g protein</p>
      </div>
    </button>
  );
}