import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function MealDetailDialog({ meal, open, onOpenChange }) {
  if (!meal) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg rounded-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-[#134E4A] break-words pr-6">{meal.mealName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-lg text-[#374151] break-words">{meal.description}</p>

          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              ["Calories", meal.calories],
              ["Protein", `${meal.protein}g`],
              ["Carbs", `${meal.carbs}g`],
              ["Fat", `${meal.fat}g`],
            ].map(([label, val]) => (
              <div key={label} className="bg-[#F0FDFA] rounded-xl p-3">
                <p className="text-base font-bold text-[#0D6B61]">{val}</p>
                <p className="text-sm text-[#4B5563]">{label}</p>
              </div>
            ))}
          </div>

          {meal.ingredients?.length > 0 && (
            <div>
              <h3 className="text-lg font-bold text-[#134E4A] mb-2">Ingredients</h3>
              <ul className="list-disc list-inside text-lg text-[#374151] space-y-1">
                {meal.ingredients.map((ing) => (
                  <li key={ing} className="break-words">{ing}</li>
                ))}
              </ul>
            </div>
          )}

          {meal.prepNotes && (
            <div className="bg-[#F9FAFB] rounded-xl p-4 border border-[#E5E7EB]">
              <h3 className="text-lg font-bold text-[#134E4A] mb-2">How to Prepare</h3>
              <ol className="list-decimal list-inside text-lg text-[#374151] space-y-2">
                {meal.prepNotes
                  .split(/\r?\n|(?<=[.!?])\s+(?=[A-Z])/)
                  .map((step) => step.trim())
                  .filter(Boolean)
                  .map((step, i) => (
                    <li key={i} className="break-words leading-relaxed">{step}</li>
                  ))}
              </ol>
            </div>
          )}

          {meal.clinicalRationale && (
            <div className="bg-[#F0FDFA] rounded-xl p-4">
              <h3 className="text-base font-bold text-[#0D6B61] mb-1">Why this meal is good for you</h3>
              <p className="text-base text-[#134E4A] break-words">{meal.clinicalRationale}</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}