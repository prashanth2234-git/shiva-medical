import React, { useState } from "react";
import { Coffee, Sandwich, Soup, Apple } from "lucide-react";
import MealCard from "./MealCard";
import MealDetailDialog from "./MealDetailDialog";

const MEAL_TYPES = ["breakfast", "lunch", "dinner", "snack"];
const MEAL_LABELS = { breakfast: "Breakfast", lunch: "Lunch", dinner: "Dinner", snack: "Snack" };
const MEAL_ICONS = { breakfast: Coffee, lunch: Sandwich, dinner: Soup, snack: Apple };

export default function MealPlanGrid({ planData }) {
  const [selectedMeal, setSelectedMeal] = useState(null);

  return (
    <div className="space-y-6">
      {/* Mobile: stacked cards per day */}
      <div className="lg:hidden space-y-6">
        {planData.map((dayData) => (
          <div key={dayData.day} className="bg-[#F0FDFA] rounded-2xl p-5">
            <h2 className="text-2xl font-bold text-[#134E4A] mb-4">{dayData.day}</h2>
            <div className="space-y-4">
              {MEAL_TYPES.map((type) => {
                const Icon = MEAL_ICONS[type];
                return (
                  <div key={type}>
                    <p className="flex items-center gap-2 text-lg font-bold text-[#0D9488] uppercase mb-2">
                      <Icon className="w-5 h-5" /> {MEAL_LABELS[type]}
                    </p>
                    <MealCard meal={dayData.meals?.[type]} onClick={() => setSelectedMeal(dayData.meals?.[type])} />
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Desktop: weekly grid */}
      <div className="hidden lg:block overflow-x-auto">
        <div className="grid grid-cols-8 gap-3 min-w-[1100px]">
          <div />
          {planData.map((dayData) => (
            <div key={dayData.day} className="text-center font-bold text-xl text-[#134E4A] py-2">
              {dayData.day}
            </div>
          ))}
          {MEAL_TYPES.map((type) => {
            const Icon = MEAL_ICONS[type];
            return (
            <React.Fragment key={type}>
              <div className="flex items-center justify-end gap-2 pr-2 font-bold text-[#0D9488] text-lg uppercase">
                <Icon className="w-5 h-5" /> {MEAL_LABELS[type]}
              </div>
              {planData.map((dayData) => (
                <MealCard
                  key={dayData.day + type}
                  meal={dayData.meals?.[type]}
                  onClick={() => setSelectedMeal(dayData.meals?.[type])}
                />
              ))}
            </React.Fragment>
            );
          })}
        </div>
      </div>

      <MealDetailDialog meal={selectedMeal} open={!!selectedMeal} onOpenChange={(o) => !o && setSelectedMeal(null)} />
    </div>
  );
}