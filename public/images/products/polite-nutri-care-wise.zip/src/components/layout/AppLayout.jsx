import React from "react";
import { Outlet } from "react-router-dom";
import TopNav from "./TopNav";
import ChatWidget from "@/components/chat/ChatWidget";

export default function AppLayout() {
  return (
    <div className="min-h-screen bg-white">
      <TopNav />
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <Outlet />
      </main>
      <ChatWidget />
    </div>
  );
}