import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Utensils, HeartPulse, HelpCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

const navItems = [
  { label: "My Meals", path: "/", icon: Utensils },
  { label: "My Health Profile", path: "/health-profile", icon: HeartPulse },
  { label: "Help", path: "/help", icon: HelpCircle },
];

export default function TopNav() {
  const location = useLocation();

  return (
    <header className="bg-white border-b-2 border-[#F3F4F6] sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-[#0D9488] flex items-center justify-center">
            <Utensils className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-bold text-[#134E4A]">NutriCare AI</span>
        </Link>

        <nav className="flex items-center gap-1 sm:gap-2">
          {navItems.map(({ label, path, icon: Icon }) => {
            const isActive = location.pathname === path;
            return (
              <Link
                key={path}
                to={path}
                className={`flex items-center gap-2 px-3 sm:px-4 py-2.5 rounded-xl text-base font-semibold transition-colors ${
                  isActive
                    ? "bg-[#CCFBF1] text-[#0D6B61]"
                    : "text-[#374151] hover:bg-[#F3F4F6]"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="hidden sm:inline">{label}</span>
              </Link>
            );
          })}
          <button
            onClick={() => base44.auth.logout()}
            className="hidden sm:block ml-2 px-4 py-2.5 rounded-xl text-base font-semibold text-[#374151] hover:bg-[#F3F4F6]"
          >
            Sign Out
          </button>
        </nav>
      </div>
    </header>
  );
}