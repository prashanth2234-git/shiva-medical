import React from "react";
import ReactMarkdown from "react-markdown";

export default function ChatMessageBubble({ message }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-2 text-sm break-words ${
          isUser ? "bg-[#0D9488] text-white" : "bg-[#F0FDFA] text-[#134E4A]"
        }`}
      >
        {isUser ? (
          <p className="whitespace-pre-wrap">{message.content}</p>
        ) : (
          <ReactMarkdown className="prose prose-sm max-w-none">{message.content || "..."}</ReactMarkdown>
        )}
      </div>
    </div>
  );
}