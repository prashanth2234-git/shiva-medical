import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { MessageCircle, X, Send } from "lucide-react";
import ChatMessageBubble from "./ChatMessageBubble";

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (open && !conversation) {
      (async () => {
        const conv = await base44.agents.createConversation({
          agent_name: "nutrition_assistant",
          metadata: { name: "NutriCare Chat", description: "NutriCare Chat" },
        });
        setConversation(conv);
        setMessages(conv.messages || []);
      })();
    }
  }, [open, conversation]);

  useEffect(() => {
    if (!conversation) return;
    const unsubscribe = base44.agents.subscribeToConversation(conversation.id, (data) => {
      setMessages(data.messages);
    });
    return () => unsubscribe();
  }, [conversation]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || !conversation || sending) return;
    const text = input.trim();
    setInput("");
    setSending(true);
    await base44.agents.addMessage(conversation, { role: "user", content: text });
    setSending(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {open ? (
        <div className="w-[350px] h-[480px] bg-white rounded-2xl shadow-2xl border-2 border-[#F3F4F6] flex flex-col overflow-hidden">
          <div className="flex items-center justify-between bg-[#0D9488] text-white px-4 py-3">
            <span className="font-bold">NutriCare Assistant</span>
            <button onClick={() => setOpen(false)}>
              <X className="w-5 h-5" />
            </button>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            {messages.length === 0 && (
              <p className="text-sm text-[#6B7280] text-center mt-4">
                Ask me about your meal plan, health profile, or nutrition!
              </p>
            )}
            {messages.map((m, i) => (
              <ChatMessageBubble key={i} message={m} />
            ))}
          </div>
          <div className="flex items-center gap-2 border-t-2 border-[#F3F4F6] p-3">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Type a message..."
              className="flex-1 h-10 rounded-xl border-2 border-[#F3F4F6] px-3 text-sm focus:outline-none focus:border-[#0D9488]"
            />
            <Button
              onClick={handleSend}
              disabled={sending || !input.trim()}
              size="icon"
              className="h-10 w-10 rounded-xl bg-[#0D9488] hover:bg-[#0B7A70] shrink-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ) : (
        <Button
          onClick={() => setOpen(true)}
          className="h-14 w-14 rounded-full bg-[#0D9488] hover:bg-[#0B7A70] shadow-xl"
        >
          <MessageCircle className="w-6 h-6" />
        </Button>
      )}
    </div>
  );
}