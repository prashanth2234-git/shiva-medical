import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { HeartPulse, RefreshCw } from "lucide-react";
import MealPlanGrid from "@/components/dashboard/MealPlanGrid";

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [dietPlan, setDietPlan] = useState(null);

  const loadData = async () => {
    const user = await base44.auth.me();
    const profiles = await base44.entities.HealthProfile.filter({ created_by_id: user.id });
    const currentProfile = profiles[0] || null;
    setProfile(currentProfile);

    if (currentProfile) {
      const plans = await base44.entities.DietPlan.filter({ healthProfileId: currentProfile.id }, "-created_date", 1);
      setDietPlan(plans[0] || null);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (dietPlan && dietPlan.status === "generating") {
      const interval = setInterval(loadData, 4000);
      return () => clearInterval(interval);
    }
  }, [dietPlan]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-10 h-10 border-4 border-[#CCFBF1] border-t-[#0D9488] rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="max-w-3xl mx-auto text-center py-10 animate-in fade-in duration-300">
        <div className="rounded-3xl overflow-hidden mb-8 relative h-64 sm:h-80">
          <img
            src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=1200&q=80"
            alt="Healthy Indian meal spread"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-[#134E4A]/40 flex items-center justify-center">
            <HeartPulse className="w-16 h-16 text-white" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-[#134E4A] mb-4">Welcome to NutriCare AI</h1>
        <p className="text-2xl text-[#374151] mb-8 leading-relaxed">
          Let's start by learning a little about you, so we can build your personal meal plan.
        </p>
        <Link to="/health-profile/edit">
          <Button className="h-16 px-10 text-2xl font-bold rounded-xl bg-[#0D9488] hover:bg-[#0B7A70]">
            Start My Health Profile
          </Button>
        </Link>
      </div>
    );
  }

  if (!dietPlan || dietPlan.status === "generating") {
    return (
      <div className="max-w-xl mx-auto text-center py-16 animate-in fade-in duration-300">
        <img
          src="https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&q=80"
          alt="Preparing your meal plan"
          className="w-32 h-32 rounded-full object-cover mx-auto mb-5 border-4 border-[#F59E0B]"
        />
        <h1 className="text-4xl font-bold text-[#134E4A] mb-4">Your Meal Plan Is Being Prepared</h1>
        <p className="text-2xl text-[#374151] mb-8 leading-relaxed">
          We're creating your personalized 7-day meal plan… this usually takes about 30 seconds ☀️
        </p>
        <div className="w-12 h-12 border-4 border-[#CCFBF1] border-t-[#F59E0B] rounded-full animate-spin mx-auto" />
      </div>
    );
  }

  if (dietPlan.status === "error") {
    return (
      <div className="max-w-xl mx-auto text-center py-16 animate-in fade-in duration-300">
        <h1 className="text-4xl font-bold text-[#134E4A] mb-4">We Ran Into a Problem</h1>
        <p className="text-2xl text-[#374151] mb-8 leading-relaxed">
          Something went wrong while preparing your meal plan. Please try updating your health profile to try again.
        </p>
        <Link to="/health-profile/edit">
          <Button className="h-16 px-10 text-2xl font-bold rounded-xl bg-[#0D9488] hover:bg-[#0B7A70]">
            <RefreshCw className="w-6 h-6 mr-2" /> Update My Profile
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="animate-in fade-in duration-300">
      <div className="rounded-3xl overflow-hidden mb-8 relative h-40 sm:h-52">
        <img
          src="https://images.unsplash.com/photo-1547592180-85f173990554?w=1200&q=80"
          alt="Your personalized meal plan"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[#134E4A]/50 flex flex-col items-center justify-center text-center px-4">
          <h1 className="text-3xl sm:text-4xl font-bold text-white">Your Meal Plan</h1>
          <p className="text-lg sm:text-2xl text-white/90 mt-1">Here's your personalized meals for the week.</p>
        </div>
      </div>
      <MealPlanGrid planData={dietPlan.planData || []} />
    </div>
  );
}