import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import StepProgress from "@/components/health-profile/StepProgress";
import CheckOptionGrid from "@/components/health-profile/CheckOptionGrid";
import RadioOptionGrid from "@/components/health-profile/RadioOptionGrid";
import HospitalReportsUpload from "@/components/health-profile/HospitalReportsUpload";
import { ChevronLeft, ChevronRight, CheckCircle2 } from "lucide-react";

const STEPS = ["Your Info", "Allergies", "Goals"];

const CONDITIONS = ["Diabetes Type 1", "Diabetes Type 2", "Hypertension", "CKD Stage 1", "CKD Stage 2", "CKD Stage 3", "CKD Stage 4", "CKD Stage 5", "Celiac Disease", "GERD", "Heart Disease", "Obesity", "Other"];
const ALLERGIES = ["Gluten", "Dairy", "Nuts", "Shellfish", "Eggs", "Soy", "Other"];
const DIETARY_PREFERENCES = ["Vegetarian", "Non-Vegetarian", "Eggetarian", "Vegan", "Jain"];
const GOALS = ["Weight Loss", "Muscle Gain", "Maintain Weight", "Improve Energy", "Manage Condition"];
const ACTIVITY_LEVELS = ["Sedentary", "Lightly Active", "Moderately Active", "Very Active"];

export default function HealthProfileForm() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [existingId, setExistingId] = useState(null);
  const [step, setStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    fullName: "",
    dateOfBirth: "",
    medicalConditions: [],
    otherConditionText: "",
    foodAllergies: [],
    otherAllergyText: "",
    dietaryPreference: "",
    fitnessGoals: "",
    activityLevel: "",
    additionalNotes: "",
    hospitalReports: [],
  });

  useEffect(() => {
    (async () => {
      const user = await base44.auth.me();
      const existing = await base44.entities.HealthProfile.filter({ created_by_id: user.id });
      if (existing.length > 0) {
        const p = existing[0];
        setExistingId(p.id);
        setForm({
          fullName: p.fullName || "",
          dateOfBirth: p.dateOfBirth || "",
          medicalConditions: p.medicalConditions || [],
          otherConditionText: p.otherConditionText || "",
          foodAllergies: p.foodAllergies || [],
          otherAllergyText: p.otherAllergyText || "",
          dietaryPreference: p.dietaryPreference || "",
          fitnessGoals: p.fitnessGoals || "",
          activityLevel: p.activityLevel || "",
          additionalNotes: p.additionalNotes || "",
          hospitalReports: p.hospitalReports || [],
        });
      }
      setLoading(false);
    })();
  }, []);

  const toggleArrayValue = (field, value) => {
    setForm((prev) => {
      const has = prev[field].includes(value);
      return { ...prev, [field]: has ? prev[field].filter((v) => v !== value) : [...prev[field], value] };
    });
  };

  const validateStep = () => {
    if (step === 1) {
      if (!form.fullName.trim()) return "Please tell us your name.";
      if (form.medicalConditions.length === 0) return "Please choose at least one condition, or select Other if none apply.";
      if (form.medicalConditions.includes("Other") && !form.otherConditionText.trim()) return "Please describe your health condition.";
    }
    if (step === 2) {
      if (form.foodAllergies.includes("Other") && !form.otherAllergyText.trim()) return "Please describe your food allergy.";
      if (!form.dietaryPreference) return "Please choose your dietary preference.";
    }
    if (step === 3) {
      if (!form.fitnessGoals) return "Please choose one goal that matters most to you.";
      if (!form.activityLevel) return "Please choose your activity level.";
    }
    return "";
  };

  const handleNext = () => {
    const err = validateStep();
    if (err) {
      setError(err);
      return;
    }
    setError("");
    setStep((s) => Math.min(s + 1, STEPS.length));
  };

  const handleBack = () => {
    setError("");
    setStep((s) => Math.max(s - 1, 1));
  };

  const handleSubmit = async () => {
    const err = validateStep();
    if (err) {
      setError(err);
      return;
    }
    setSubmitting(true);
    setError("");
    try {
      if (existingId) {
        await base44.entities.HealthProfile.update(existingId, form);
      } else {
        await base44.entities.HealthProfile.create(form);
      }
      navigate("/");
    } catch (e) {
      setError("Something went wrong saving your profile. Please try again.");
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-10 h-10 border-4 border-[#CCFBF1] border-t-[#0D9488] rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto animate-in fade-in duration-300">
      <h1 className="text-3xl font-bold text-[#134E4A] mb-2 text-center">
        {existingId ? "Update Your Health Profile" : "Let's Get to Know You"}
      </h1>
      <p className="text-lg text-[#4B5563] text-center mb-8">
        This helps us build your personal meal plan.
      </p>

      <StepProgress steps={STEPS} currentStep={step} />

      <div className="bg-white rounded-2xl border-2 border-[#F3F4F6] p-6 sm:p-8">
        {step === 1 && (
          <div className="space-y-6">
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-2 block">What's your full name?</Label>
              <Input
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="Jane Smith"
                className="h-14 text-lg rounded-xl border-2"
              />
            </div>
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-2 block">Date of birth (optional)</Label>
              <Input
                type="date"
                value={form.dateOfBirth}
                onChange={(e) => setForm({ ...form, dateOfBirth: e.target.value })}
                className="h-14 text-lg rounded-xl border-2"
              />
            </div>
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-3 block">
                Do you have any of these health conditions?
              </Label>
              <CheckOptionGrid
                options={CONDITIONS}
                selected={form.medicalConditions}
                onToggle={(v) => toggleArrayValue("medicalConditions", v)}
              />
            </div>
            {form.medicalConditions.includes("Other") && (
              <div>
                <Label className="text-lg font-semibold text-[#134E4A] mb-2 block">
                  Please describe your health condition
                </Label>
                <Textarea
                  value={form.otherConditionText}
                  onChange={(e) => setForm({ ...form, otherConditionText: e.target.value })}
                  placeholder="Tell us about your condition..."
                  className="text-lg rounded-xl border-2 min-h-[80px]"
                />
              </div>
            )}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-3 block">
                Do you have any food allergies? (Choose any that apply)
              </Label>
              <CheckOptionGrid
                options={ALLERGIES}
                selected={form.foodAllergies}
                onToggle={(v) => toggleArrayValue("foodAllergies", v)}
              />
            </div>
            {form.foodAllergies.includes("Other") && (
              <div>
                <Label className="text-lg font-semibold text-[#134E4A] mb-2 block">
                  Please describe your food allergy
                </Label>
                <Textarea
                  value={form.otherAllergyText}
                  onChange={(e) => setForm({ ...form, otherAllergyText: e.target.value })}
                  placeholder="Tell us about your allergy..."
                  className="text-lg rounded-xl border-2 min-h-[80px]"
                />
              </div>
            )}
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-3 block">
                What's your dietary preference?
              </Label>
              <RadioOptionGrid
                options={DIETARY_PREFERENCES}
                selected={form.dietaryPreference}
                onSelect={(v) => setForm({ ...form, dietaryPreference: v })}
              />
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-3 block">
                What's your main goal?
              </Label>
              <RadioOptionGrid
                options={GOALS}
                selected={form.fitnessGoals}
                onSelect={(v) => setForm({ ...form, fitnessGoals: v })}
              />
            </div>
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-3 block">
                How active are you day-to-day?
              </Label>
              <RadioOptionGrid
                options={ACTIVITY_LEVELS}
                selected={form.activityLevel}
                onSelect={(v) => setForm({ ...form, activityLevel: v })}
              />
            </div>
            <div>
              <Label className="text-lg font-semibold text-[#134E4A] mb-2 block">
                Anything else we should know? (optional)
              </Label>
              <Textarea
                value={form.additionalNotes}
                onChange={(e) => setForm({ ...form, additionalNotes: e.target.value })}
                placeholder="Share anything that helps us plan your meals..."
                className="text-lg rounded-xl border-2 min-h-[100px]"
              />
            </div>
            <HospitalReportsUpload
              reports={form.hospitalReports}
              onChange={(reports) => setForm({ ...form, hospitalReports: reports })}
            />
          </div>
        )}

        {error && (
          <div className="mt-6 p-4 bg-[#FEF3C7] border-2 border-[#F59E0B] rounded-xl text-[#92400E] text-lg font-medium">
            {error}
          </div>
        )}

        <div className="flex items-center justify-between mt-8 gap-4">
          <Button
            type="button"
            onClick={handleBack}
            disabled={step === 1}
            variant="outline"
            className="h-14 px-6 text-lg font-semibold rounded-xl border-2 disabled:opacity-40"
          >
            <ChevronLeft className="w-5 h-5 mr-1" /> Back
          </Button>

          {step < STEPS.length ? (
            <Button
              type="button"
              onClick={handleNext}
              className="h-14 px-8 text-lg font-semibold rounded-xl bg-[#0D9488] hover:bg-[#0B7A70]"
            >
              Next <ChevronRight className="w-5 h-5 ml-1" />
            </Button>
          ) : (
            <Button
              type="button"
              onClick={handleSubmit}
              disabled={submitting}
              className="h-14 px-8 text-lg font-semibold rounded-xl bg-[#F59E0B] hover:bg-[#D97706] text-white"
            >
              {submitting ? (
                "Saving..."
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5 mr-2" /> Save My Profile
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}