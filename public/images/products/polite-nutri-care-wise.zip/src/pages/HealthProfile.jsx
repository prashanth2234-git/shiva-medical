import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Pencil, HeartPulse, FileText } from "lucide-react";

function InfoBlock({ label, value }) {
  return (
    <div className="py-4 border-b border-[#F3F4F6] last:border-b-0">
      <p className="text-base font-semibold text-[#6B7280] mb-1">{label}</p>
      <p className="text-lg text-[#134E4A]">{value}</p>
    </div>
  );
}

export default function HealthProfile() {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const user = await base44.auth.me();
      const existing = await base44.entities.HealthProfile.filter({ created_by_id: user.id });
      setProfile(existing[0] || null);
      setLoading(false);
    })();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-10 h-10 border-4 border-[#CCFBF1] border-t-[#0D9488] rounded-full animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="max-w-xl mx-auto text-center py-16">
        <HeartPulse className="w-14 h-14 text-[#0D9488] mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-[#134E4A] mb-3">You haven't created a health profile yet</h1>
        <p className="text-lg text-[#4B5563] mb-6">Tell us about yourself so we can build your meal plan.</p>
        <Link to="/health-profile/edit">
          <Button className="h-14 px-8 text-lg font-semibold rounded-xl bg-[#0D9488] hover:bg-[#0B7A70]">
            Start My Profile
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto animate-in fade-in duration-300">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-[#134E4A]">My Health Profile</h1>
        <Link to="/health-profile/edit">
          <Button variant="outline" className="h-12 px-5 text-base font-semibold rounded-xl border-2">
            <Pencil className="w-4 h-4 mr-2" /> Edit
          </Button>
        </Link>
      </div>

      <div className="bg-white rounded-2xl border-2 border-[#F3F4F6] p-6 sm:p-8">
        <InfoBlock label="Full Name" value={profile.fullName} />
        {profile.dateOfBirth && (
          <InfoBlock label="Date of Birth" value={new Date(profile.dateOfBirth).toLocaleDateString("en-IN")} />
        )}
        <InfoBlock
          label="Health Conditions"
          value={profile.medicalConditions?.length ? profile.medicalConditions.join(", ") : "None reported"}
        />
        <InfoBlock
          label="Food Allergies"
          value={profile.foodAllergies?.length ? profile.foodAllergies.join(", ") : "None reported"}
        />
        <InfoBlock label="Dietary Preference" value={profile.dietaryPreference || "Not set"} />
        <InfoBlock label="Main Goal" value={profile.fitnessGoals || "Not set"} />
        <InfoBlock label="Activity Level" value={profile.activityLevel || "Not set"} />
        {profile.additionalNotes && <InfoBlock label="Additional Notes" value={profile.additionalNotes} />}
        {profile.hospitalReports?.length > 0 && (
          <div className="py-4">
            <p className="text-base font-semibold text-[#6B7280] mb-2">Hospital Reports</p>
            <div className="space-y-2">
              {profile.hospitalReports.map((r, i) => (
                <a
                  key={i}
                  href={r.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 bg-[#F0FDFA] rounded-xl px-4 py-3 text-[#134E4A] hover:bg-[#CCFBF1] transition-colors"
                >
                  <FileText className="w-5 h-5 text-[#0D9488] shrink-0" />
                  <span className="truncate">{r.name}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}