import React from "react";
import { HelpCircle, Mail } from "lucide-react";

const FAQS = [
  {
    q: "How do I get my meal plan?",
    a: "Fill out your Health Profile with your name, health conditions, allergies, and goals. Once you save it, we'll prepare your personalized 7-day meal plan automatically. This takes about 30 seconds.",
  },
  {
    q: "Can I change my meal plan later?",
    a: "Yes! Just go to My Health Profile, choose Edit, update your information, and save. We'll create a fresh meal plan for you right away.",
  },
  {
    q: "Is my health information private?",
    a: "Yes. Your health information is only used to create your meal plan and is never shared with other patients.",
  },
  {
    q: "What if a meal doesn't look right for me?",
    a: "Every meal is created based on the health information you shared. If something looks off, update your Health Profile and we'll regenerate your plan.",
  },
];

export default function Help() {
  return (
    <div className="max-w-2xl mx-auto animate-in fade-in duration-300">
      <div className="text-center mb-8">
        <HelpCircle className="w-14 h-14 text-[#0D9488] mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-[#134E4A]">Help & Questions</h1>
        <p className="text-lg text-[#4B5563] mt-2">We're here to make this easy for you.</p>
      </div>

      <div className="space-y-4">
        {FAQS.map((item) => (
          <div key={item.q} className="bg-white rounded-2xl border-2 border-[#F3F4F6] p-6">
            <h2 className="text-xl font-bold text-[#134E4A] mb-2">{item.q}</h2>
            <p className="text-lg text-[#374151] leading-relaxed">{item.a}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 bg-[#F0FDFA] rounded-2xl p-6 flex items-center gap-4">
        <Mail className="w-8 h-8 text-[#0D9488] shrink-0" />
        <p className="text-lg text-[#134E4A]">
          Still need help? Reach out to your care team for support with your account.
        </p>
      </div>
    </div>
  );
}