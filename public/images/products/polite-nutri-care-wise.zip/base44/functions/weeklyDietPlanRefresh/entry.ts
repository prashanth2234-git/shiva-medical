import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const profiles = await base44.asServiceRole.entities.HealthProfile.list();
    const results = [];

    for (const profile of profiles) {
      try {
        const genResult = await base44.asServiceRole.functions.invoke('generateDietPlan', {
          healthProfileId: profile.id
        });
        const dietPlan = genResult.data?.dietPlan;

        if (dietPlan && dietPlan.status === 'ready' && profile.created_by_id) {
          const patientUser = await base44.asServiceRole.entities.User.get(profile.created_by_id);
          if (patientUser?.email) {
            const emailBody = buildEmailBody(profile, dietPlan);
            await base44.asServiceRole.integrations.Core.SendEmail({
              to: patientUser.email,
              subject: 'Your Updated 7-Day Meal Plan',
              body: emailBody,
              from_name: 'NutriCare AI'
            });
          }
        }
        results.push({ healthProfileId: profile.id, status: dietPlan?.status || 'unknown' });
      } catch (innerError) {
        results.push({ healthProfileId: profile.id, status: 'error', error: innerError.message });
      }
    }

    return Response.json({ success: true, processed: results.length, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function buildEmailBody(profile, dietPlan) {
  const dayLines = (dietPlan.planData || []).map((day) => {
    const meals = day.meals || {};
    const mealLines = ['breakfast', 'lunch', 'dinner', 'snack']
      .filter((type) => meals[type])
      .map((type) => `  - ${capitalize(type)}: ${meals[type].mealName}`)
      .join('\n');
    return `${day.day}:\n${mealLines}`;
  }).join('\n\n');

  return `Hi ${profile.fullName},\n\nHere is your updated 7-day meal plan:\n\n${dayLines}\n\nLog in to your NutriCare AI account to see full meal details, ingredients, and preparation notes.\n\nStay healthy!\nNutriCare AI`;
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}