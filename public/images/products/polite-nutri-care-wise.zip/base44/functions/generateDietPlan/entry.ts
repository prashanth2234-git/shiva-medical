import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const healthProfileId = body.healthProfileId;
    if (!healthProfileId) {
      return Response.json({ error: 'healthProfileId is required' }, { status: 400 });
    }

    const profile = await base44.asServiceRole.entities.HealthProfile.get(healthProfileId);
    if (!profile) {
      return Response.json({ error: 'HealthProfile not found' }, { status: 404 });
    }

    const existingPlans = await base44.asServiceRole.entities.DietPlan.filter({ healthProfileId });
    let dietPlan;
    if (existingPlans.length > 0) {
      dietPlan = await base44.asServiceRole.entities.DietPlan.update(existingPlans[0].id, { status: 'generating' });
    } else {
      dietPlan = await base44.asServiceRole.entities.DietPlan.create({
        healthProfileId,
        status: 'generating',
        weekStartDate: new Date().toISOString().split('T')[0]
      });
    }

    const systemPrompt = `You are a certified clinical nutritionist creating a personalized 7-day meal plan.
Patient profile:
- Name: ${profile.fullName}
- Medical conditions: ${(profile.medicalConditions || []).join(', ') || 'None reported'}${profile.otherConditionText ? ` (Other condition described by patient: ${profile.otherConditionText})` : ''}
- Food allergies: ${(profile.foodAllergies || []).join(', ') || 'None reported'}${profile.otherAllergyText ? ` (Other allergy described by patient: ${profile.otherAllergyText})` : ''}
- Dietary preference: ${profile.dietaryPreference || 'Not specified'}
- Fitness goal: ${profile.fitnessGoals || 'Not specified'}
- Activity level: ${profile.activityLevel || 'Not specified'}
- Additional notes: ${profile.additionalNotes || 'None'}

Clinical guidance to apply:
- Hypertension: low-sodium meals
- Diabetes (Type 1 or 2): low glycemic-index, controlled carbohydrate meals
- CKD (any stage): phosphorus and potassium restricted, moderate protein
- Celiac Disease: strictly gluten-free
- GERD: avoid acidic/spicy/fatty trigger foods
- Heart Disease: low saturated fat, heart-healthy meals
- Obesity: calorie-controlled, high satiety meals
Always strictly avoid the patient's listed food allergies, including any custom allergy they described in their own words.
If the patient described their own custom health condition, take it seriously and tailor the meals to be appropriate for it.
Strictly honor the patient's dietary preference (e.g. Vegetarian, Non-Vegetarian, Eggetarian, Vegan, Jain — Jain means no onion, garlic, or root vegetables).

This patient is based in India. Build the meal plan around everyday Indian home-cooking using regional Indian dishes and ingredients (e.g. dal, roti/chapati, sabzi, rice, poha, idli, dosa, paneer, curd, khichdi, upma) rather than Western meal templates. Adapt these dishes to fit the patient's medical conditions (e.g. low-oil sabzi for heart disease, low-GI millets like jowar/bajra for diabetes, low-sodium dal for hypertension).

Produce a structured 7-day meal plan (Monday through Sunday), each day with breakfast, lunch, dinner, and snack.
For every meal include: mealName, a short plain-English description (1 sentence), a short ingredients list (max 5 items), brief prep notes (1 short sentence), estimated calories/protein/carbs/fat, and a brief clinicalRationale (1 short sentence, plain English, no jargon).
Keep every text field concise to keep the response compact.
Handle patient health data with HIPAA-appropriate care — do not include any identifying information beyond what's needed for the plan itself.`;

    const responseSchema = {
      type: 'object',
      properties: {
        days: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              day: { type: 'string' },
              meals: {
                type: 'object',
                properties: {
                  breakfast: mealSchema(),
                  lunch: mealSchema(),
                  dinner: mealSchema(),
                  snack: mealSchema()
                },
                required: ['breakfast', 'lunch', 'dinner', 'snack']
              }
            },
            required: ['day', 'meals']
          }
        }
      },
      required: ['days']
    };

    function mealSchema() {
      return {
        type: 'object',
        properties: {
          mealName: { type: 'string' },
          description: { type: 'string' },
          ingredients: { type: 'array', items: { type: 'string' } },
          prepNotes: { type: 'string' },
          calories: { type: 'number' },
          protein: { type: 'number' },
          carbs: { type: 'number' },
          fat: { type: 'number' },
          clinicalRationale: { type: 'string' }
        },
        required: ['mealName', 'description', 'ingredients', 'prepNotes', 'calories', 'protein', 'carbs', 'fat', 'clinicalRationale']
      };
    }

    let aiResult;
    try {
      aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: systemPrompt,
        response_json_schema: responseSchema,
        model: 'gemini_3_flash'
      });
    } catch (aiError) {
      await base44.asServiceRole.entities.DietPlan.update(dietPlan.id, {
        status: 'error',
        errorMessage: aiError.message
      });
      return Response.json({ error: 'AI generation failed', details: aiError.message }, { status: 500 });
    }

    const planData = (aiResult.days || []).map((d) => ({
      day: d.day,
      meals: d.meals
    }));

    const updated = await base44.asServiceRole.entities.DietPlan.update(dietPlan.id, {
      planData,
      status: 'ready',
      generatedAt: new Date().toISOString(),
      errorMessage: null
    });

    return Response.json({ success: true, dietPlan: updated });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});